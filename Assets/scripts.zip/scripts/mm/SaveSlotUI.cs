using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SaveSlotUI : MonoBehaviour
{
    [SerializeField] private Button button;
    [SerializeField] private Image background;
    [SerializeField] private TextMeshProUGUI saveNameText;
    [SerializeField] private TextMeshProUGUI saveDateText;
    [SerializeField] private TextMeshProUGUI saveSceneText;

    private string savePath;
    private MainMenuLoadController owner;

    public void Setup(SaveFileData data, string filePath, MainMenuLoadController controller)
    {
        savePath = filePath;
        owner = controller;

        if (saveNameText != null)
            saveNameText.text = string.IsNullOrWhiteSpace(data.saveName) ? "��� �����" : data.saveName;

        if (saveDateText != null)
            saveDateText.text = data.createdAt;

        if (saveSceneText != null)
            saveSceneText.text = $"�����: {data.sceneName}";

        if (button != null)
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(OnClick);
        }
    }

    private void OnClick()
    {
        owner.SelectSave(savePath, this);
    }

    public void SetSelected(bool selected)
    {
        if (background == null) return;

        background.color = selected
            ? new Color(0.8f, 0.8f, 0.8f, 0.9f)
            : new Color(1f, 1f, 1f, 0.35f);
    }
}
